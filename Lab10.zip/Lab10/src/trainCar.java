import java.awt.event.*;
import java.awt.*;
import java.applet.*;
import java.util.*;



@SuppressWarnings("unused")
class trainCar extends colorTrain{
  
  trainCar(int xAdjust){
	  
	  setAdjust(xAdjust);
	  
  }

}