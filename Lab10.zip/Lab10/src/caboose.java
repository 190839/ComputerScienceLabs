import java.awt.Color;
import java.awt.Graphics;

class caboose extends superTrain{
	
	caboose(Graphics g, int xAdjust){//Main method
		  
		  setBaseColor(new Color(255,40,40));
		  setAdjust(xAdjust);
		  
		  buildCar(g);
		  buildCapola(g, xAdjust);
		  installWindows(g, xAdjust);
		
	  }//End of main method
	  
	  
	  
	  public void buildCapola(Graphics g, int xAdjust){
		  
		  //setAdjust(xAdjust);
		  
		  Color guardColor = getBaseColor();
		  g.setColor(guardColor);
		  
		  //x,y,width,height
		  g.fillRect(p1+xAdjust+20, p2-15, p3-40, 15);
		  g.setColor(black);
		  g.fillRect(p1+xAdjust+10, p2-20, p3-20, 5);
		  
	  }
	  
	  
	  public void installWindows(Graphics g, int xAdjust){

		//x,y,width,height
		  g.setColor(white);
		  int l = 30;
		  g.fillRect(p1+xAdjust+20, p2+20, l, l);
		  g.fillRect(p1+xAdjust+100, p2+20, l, l); //Car width = 150; Window width = 30; We want to be 20 over...
		  
	  }

}